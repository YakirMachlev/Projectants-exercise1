#include <stdio.h>
#include <stdlib.h>

typedef char bool;

bool is_alnum(char tav)
{
    return (tav >= 'a' && tav <= 'z') || (tav >= 'A' && tav <= 'Z') || (tav >= '0' && tav <= '9');
}

void contract(char str[], char shortened_str[])
{
    char* temp;

    while (*str)
    {
        *(shortened_str++) = *str;
        temp = str;

        while (*(temp + 1) == *temp + 1 && is_alnum(*temp) && is_alnum(*(temp + 1)))
            temp++;
        if (temp - str >= 2) //if the ascending sequence is longer two chars or more
        {
            *(shortened_str++) = '-';
            *(shortened_str++) = *temp;
        }

        str = temp + (temp - str != 1); //continue to the next sequence
    }
}

int main()
{
    char str[81];
    char shortened_str[81];

    printf("Enter the string: ");
    fgets(str, sizeof(str), stdin);
    printf("\nThe original string is: %s", str);

    contract(str, shortened_str);
    printf("\nThe shortened string is: %s\n", shortened_str);
}