#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "stackLibrary.h"
#include "stackLibrary.c"

typedef char bool;

bool is_opening_bracket(char tav)
{
    return tav == '{' || tav == '[' || tav == '(';
}

bool is_closing_bracket(char tav)
{
    return tav == '}' || tav == ']' || tav == ')';
}

char complementary_open_bracket(char tav)
{
    return tav == ')' ? tav - 1 : tav - 2;
}

bool is_special_line(char* line, char* special_tav)
{
    char count;
    bool special;

    count = 0;
    special = 1;
    while (*line && special)
    {
        if (*line == '{' || *line == '}')
        {
            count++;
            *special_tav = *line;
        }
        else if (isspace(*line))
            ;
        else
            special = 0;
        line++;
    }
    return special && count == 1;
}

bool balanced_line(char line[], char* comment)
{
    stackPtr stk;
    int len;
    bool balanced;

    balanced = 1;
    stk = (stackPtr)malloc(sizeof(stack) * STACK_SIZE);
    init_stack(stk);

    while(*line && (balanced || !(*comment)))
    {
        if (*line == '/' && *(line + 1) == '*')
        {
            *comment = 1;
            line += 2;
            while (*(line + 1) && (*line != '*' || *(line + 1) != '/'))
                line++;
            *comment += *(line + 1) != '\0';
        }
        else if (*line && (*line == '*' && *(line + 1) == '/'))
        {
            *comment = 1;
            balanced = 1;
            line++;
        }
        else if (*line == '"')
        {
            line++;
            while (*(line++) != '"');
            line--;
        }
        else if (is_opening_bracket(*line))
            push_stack(stk, *line);
        else if (is_closing_bracket(*line))
            balanced = !(is_stack_empty(stk) || pop_stack(stk) != complementary_open_bracket(*line));
        
        line++;
    }
    
    return balanced && is_stack_empty(stk);
}

void balanced_text()
{
    int line_num;
    char line[100];
    bool balanced;
    bool is_current_line_balanced;
    char is_comment;
    char special;
    char balanced_text[6];
    int curly_brackets_count;
    
    line_num = 1;
    fgets(line, sizeof(line), stdin);
    balanced = 1;
    curly_brackets_count = 0;
    is_comment = 0;

    while (line[0] != '^') //EOD
    {
        if (is_special_line(line, &special))
        {
            printf("Line %d is unbalanced: %s", line_num, line);
            curly_brackets_count += special == '{' ? 1 : -1;
        }
        else
        {
            is_current_line_balanced = balanced_line(line, &is_comment);
            is_current_line_balanced ? strcpy(balanced_text, "is ") : strcpy(balanced_text, "is un");
            printf("Line %d %sbalanced: %s", line_num, balanced_text, line);

            if (is_comment == 1)
            {
                is_comment = 0;
                fgets(line, sizeof(line), stdin);
                line_num++;
                is_current_line_balanced = balanced_line(line, &is_comment);
                while (is_comment != 1) //find the row in which the comment ends
                {
                    printf("Line %d is balanced: %s", line_num, line);
                    fgets(line, sizeof(line), stdin);
                    line_num++;
                    is_current_line_balanced = balanced_line(line, &is_comment);
                }
                is_current_line_balanced ? strcpy(balanced_text, "is ") : strcpy(balanced_text, "is un");
                printf("Line %d %sbalanced: %s", line_num, balanced_text, line);
                is_comment = 0;
            }
            balanced &= is_current_line_balanced;
        }

        fgets(line, sizeof(line), stdin);
        line_num++;
    }

    balanced &= !curly_brackets_count;
    if (balanced)
        printf("All brackets are balanced.\n");
    else
        printf("Not all brackets are balanced.\n");
}

int main(int argc, char* argv[])
{
    printf("Enter the code:\n");
    balanced_text();
}