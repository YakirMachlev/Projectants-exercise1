#pragma once
#include "stackLibrary.h"

//-----------------------------------------------------------------------------
//                                   init_stack
//                                  ------------
//
// General: The function initializes a stack
//
// Parameters:
// stkPtr - A pointer, pointing at the stack that we want to initialize (I/O)
//
// Return Value: None
//
// Input size: None
// Run-Time function: f(n) = d
// Complexity: O(1)
//
//-----------------------------------------------------------------------------
void init_stack(stackPtr stkPtr)
{
	stkPtr->top = -1;
}

//-----------------------------------------------------------------------------
//                                   pop_stack
//                                  -----------
//
// General: The function removes the last entered value from the stack
//
// Parameters:
// stkPtr - A pointer, pointing at the stack from which we want to remove a
// value (I/O)
//
// Return Value: The value of the last entered item in the stack
//
// Input size: None
// Run-Time function: f(n) = d
// Complexity: O(1)
//
//-----------------------------------------------------------------------------
TYP pop_stack(stackPtr stkPtr)
{
	return *(stkPtr->vec + (stkPtr->top)--);
}

//-----------------------------------------------------------------------------
//                                  peek_stack
//                                 ------------
//
// General: The function returns the last entered value from the stack
//
// Parameters:
// stkPtr - A pointer, pointing at the stack from which we want to see a
// value (I/O)
//
// Return Value: The value of the last entered item in the stack
//
// Input size: None
// Run-Time function: f(n) = d
// Complexity: O(1)
//
//-----------------------------------------------------------------------------
TYP peek_stack(stackPtr stkPtr)
{
	return stkPtr->vec[stkPtr->top];
}

//-----------------------------------------------------------------------------
//                                   push_stack
//                                  ------------
//
// General: The function adds a value to a stack
//
// Parameters:
// stkPtr - A pointer, pointing at the stack that we want to add a value to (I/O)
//
// Return Value: None
//
// Input size: None
// run-time function: f(n) = d
// Complexity: O(1)
//
//-----------------------------------------------------------------------------
void push_stack(stackPtr stkPtr, TYP value)
{
	*(stkPtr->vec + (++(stkPtr->top))) = value;
}

//-----------------------------------------------------------------------------
//                               is_stack_empty
//                              ----------------
//
// General: The function checks if a stack holds is empty (the stack's top is -1)
//
// Parameters:
// stkPtr - A pointer, pointing at the stack that we want to check (In)
//
// Return Value: Is the stack empty (1/0)
// 
// Input size: None
// run-time function: f(n) = d
// Complexity: O(1)
//
//-----------------------------------------------------------------------------
BOOL is_stack_empty(stackPtr stkPtr)
{
	return stkPtr->top == -1;
}

//-----------------------------------------------------------------------------
//                               copy_stack
//                              ------------
//
// General: The function copies the values of a stack to another stack
//
// Parameters:
// stkPtr - A pointer, pointing at the stack that we want to copy (In)
// copyStackPtr - A pointer, pointing at the stack that we want to copy to (I/O)
//
// Return Value: None
//
// Input size: The distance from 0 to (stkPtr->top + 1)
// run-time function: f(n) = n*(c1 + c2) + d
// Complexity: O(n)
//
//-----------------------------------------------------------------------------
void copy_stack(stackPtr stkPtr, stackPtr copyStackPtr)
{
	TYP vec[STACK_SIZE];
	int size;
	int pos;

	size = 0;
	init_stack(copyStackPtr);

	while (!is_stack_empty(stkPtr))
	{
		vec[size++] = pop_stack(stkPtr);
	}
	for (pos = size - 1; pos >= 0; pos--)
	{
		push_stack(stkPtr, vec[pos]);
		push_stack(copyStackPtr, vec[pos]);
	}
}

//-----------------------------------------------------------------------------
//                               opposite_stack
//                              ----------------
//
// General: The function reverses the values order in a stack
//
// Parameters:
// stkPtr - A pointer, pointing at the stack that we want to reverse (I/O)
//
// Return Value: None
//
// Input size: The distance from 0 to (stkPtr->top + 1)
// run-time function: f(n) = n*(c1 + c2) + d
// Complexity: O(n)
//
//-----------------------------------------------------------------------------
void opposite_stack(stackPtr stkPtr)
{
	TYP vec[STACK_SIZE];
	int size;
	int pos;

	size = 0;
	while (!is_stack_empty(stkPtr))
	{
		vec[size++] = pop_stack(stkPtr);
	}
	for (pos = 0; pos < size; pos++)
	{
		push_stack(stkPtr, vec[pos]);
	}
}

//-----------------------------------------------------------------------------
//								 print_stack
//								-------------
//
// General: The function prints all of the stack's values
//
// Parameters:
// stkPtr - A pointer, pointing at the stack the we print its values (In)
//
// Return Value: None
//
// Input size: The distance from 0 to (stkPtr->top + 1)
// Run-Time function: f(n) = cn + d
// Complexity: O(n)
//
//-----------------------------------------------------------------------------
void print_stack(stackPtr stkPtr)
{
	stack temp;
	stackPtr tempPtr;

	tempPtr = &temp;
	copy_stack(stkPtr, tempPtr);
	opposite_stack(tempPtr);

	while (!is_stack_empty(tempPtr))
	{
		printf("%d ", pop_stack(&temp));
	}
	printf("\n");
}