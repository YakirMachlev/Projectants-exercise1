#pragma once

#ifndef STACK
	#define STACK
	
	#include <stdio.h>
	#include <stdlib.h>

	#ifndef STACK_SIZE
		#define STACK_SIZE 100
	#endif

	#ifndef STRING_SIZE
		#define STRING_SIZE 50
		typedef char string[STRING_SIZE];
	#endif

	#ifndef BOOL
		#define BOOL char
	#endif

	#ifndef TYP
		#define TYP char
	#endif

	typedef struct stack
	{
		TYP vec[STACK_SIZE];
		int top;
	}
	stack, *stackPtr;

	void init_stack(stackPtr);
	TYP pop_stack(stackPtr);
	TYP peek_stack(stackPtr);
	void push_stack(stackPtr, TYP);
	BOOL is_stack_empty(stackPtr);
	void copy_stack(stackPtr, stackPtr);
	void opposite_stack(stackPtr);
	void print_stack(stackPtr);
#endif