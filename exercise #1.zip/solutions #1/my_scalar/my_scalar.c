#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int scalar_product(int vec1[], int vec2[], int size)
{
    int product = 0;
    int offset;

    for (offset = 0; offset < size; offset++)
        product += vec1[offset] * vec2[offset];

    return product;
}

int calculate_product()
{
    int size;
    int* vec1;
    int* vec2;
    int offset;
    int product;
    char line[100];
    char* token;

    printf("Enter the size of the vectors: ");
    fgets(line, sizeof(line), stdin);
    fprintf(stdout, "%s", line);
    size = atoi(line);

    vec1 = (int*)malloc(size * sizeof(int));
    vec2 = (int*)malloc(size * sizeof(int));

    printf("Enter the values for the first vector: ");
    fgets(line, sizeof(line), stdin);
    fprintf(stdout, "%s", line);
    token = strtok(line, ",");
    offset = 0;
    while (token != NULL && offset < size)
    {
        vec1[offset++] = atoi(token);
        token = strtok(NULL, ",");
    }
    
    printf("Enter the values for the second vector: ");
    fgets(line, sizeof(line), stdin);
    fprintf(stdout, "%s", line);
    token = strtok(line, ",");
    offset = 0;
    while (token != NULL && offset < size)
    {
        vec2[offset++] = atoi(token);
        token = strtok(NULL, ",");
    }

    product = scalar_product(vec1, vec2, size);
    return product;
}


int main(int argc, char* argv[])
{
    int product;
    product = calculate_product();
    printf("\nThe product is: %d\n", product);
}