#include <stdio.h>
#include <stdlib.h>

#define RIGHT_BIT(x) ((x) & 1)

int parallel_on_bits(unsigned long x, unsigned long y)
{
    int i;
    int count = 0;

    for (i = 0; i < sizeof(unsigned long) * 8; i++)
    {
        count += RIGHT_BIT(x) & RIGHT_BIT(y);
        x >>= 1;
        y >>= 1;
    }
    return count;
}

unsigned long find_msb(unsigned long num)
{
    int offset;
    int count;

    count = 0;
    while (num)
    {
        count++;
        if (num % 2 == 1)
            offset = count;
        num /= 2;
    }
    return (1 << (offset - 1));
}

void print_in_binary(unsigned long num)
{
    int i;
    char bit;
    int temp;
    unsigned long mask;

    mask = find_msb(num);
    while (mask)
    {
        bit = (num & mask) ? 1 : 0;
        printf("%d", bit);
        mask >>= 1;
    }
    printf("\n");
}

void main()
{
    unsigned long x;
    unsigned long y;
    char line[sizeof(unsigned long)];

    printf("Enter the first number: ");
    fgets(line, sizeof(line), stdin);
    x = atoi(line);
    fprintf(stdout, "%lu", x);
    printf("\nThe 1st number in binary is: ");
    print_in_binary(x);

    printf("Enter the second number: ");
    fgets(line, sizeof(line), stdin);
    y = atoi(line);
    fprintf(stdout, "%lu", y);
    printf("\nThe 2nd number in binary is: ");
    print_in_binary(y);

    printf("The amount of parallel bits that are on is: %d\n", parallel_on_bits(x, y));
}